#!/bin/sh
#apache2-foreground && chmod o-w /var/lock/apache2/ && chmod o-w /var/run/apache2/ && rm -rf /usr/local/bin/* && rm -rf /bin/* && rm -rf /sbin/*
apache2-foreground
