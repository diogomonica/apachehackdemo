#! /bin/env sh

echo "Installing..."
